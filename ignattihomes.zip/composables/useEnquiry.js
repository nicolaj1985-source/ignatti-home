// Single submission path for every enquiry form on the site
// (Collection introduction, Invest requirements, Contact).
//
// There is no backend yet, so this resolves successfully and lets the form
// show its inline/modal success state. When an email service or API route is
// ready, wire it in the one place marked below — every form benefits at once.
export async function submitEnquiry(payload) {
  // ──────────────────────────────────────────────────────────────────────
  // TODO: connect the real submission endpoint here, e.g.
  //   await $fetch('/api/enquiry', { method: 'POST', body: payload })
  // (add server/api/enquiry.post.ts, or POST to Resend / Formspree / etc.)
  // ──────────────────────────────────────────────────────────────────────
  if (import.meta.dev) {
    console.info('[enquiry] captured (no backend connected yet):', payload)
  }
  return { ok: true }
}
