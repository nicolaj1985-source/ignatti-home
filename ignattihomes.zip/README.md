# Ignatti Homes

Luxury villa management on the Costa del Sol — the marketing site, built with
**Nuxt 3**. This is a faithful conversion of the original single-file HTML
prototypes into a structured, routable, content-managed project. The visual
design is unchanged: same fonts, colours, spacing and layout.

- **Framework:** Nuxt 3 (Vue 3)
- **Content:** [Nuxt Content](https://content.nuxt.com) — Explore articles are markdown files
- **SEO:** per-page meta + Open Graph via Nuxt's built-in `useSeoMeta`, and an auto-generated sitemap via [`@nuxtjs/sitemap`](https://nuxtseo.com/sitemap)
- **Fonts:** DM Serif Display + Inter (Google Fonts)
- **Styling:** the prototype CSS, kept verbatim — design tokens in `assets/css/main.css`, everything else scoped to its component/page. (No Tailwind: keeping the original CSS is the most faithful reproduction.)

---

## Quick start

```bash
npm install      # install dependencies
npm run dev      # start the dev server at http://localhost:3000
```

Other scripts:

```bash
npm run build     # production build (Node server output)
npm run generate  # fully pre-rendered static site (also produced by build via crawl)
npm run preview   # preview the built site locally
```

---

## Project structure

```
ignatti-homes/
├── app.vue                     # Root — wraps every page in the default layout
├── nuxt.config.ts              # Modules, fonts, site URL, pre-render config
├── assets/css/main.css         # Design tokens + shared type/button primitives
├── layouts/
│   └── default.vue             # Navbar + page + Footer (every page)
├── components/
│   ├── Logo.vue                # "ignatti Homes" wordmark (nav + footer)
│   ├── SiteNav.vue             # Canonical fixed navbar
│   ├── SiteFooter.vue          # Canonical off-white footer
│   ├── SectionLabel.vue        # Small red uppercase eyebrow
│   ├── LifestyleBreak.vue      # Full-bleed photo break (homepage, About)
│   ├── ArticleCard.vue         # Editorial card (Explore grid + "More" strip)
│   └── EnquiryModal.vue        # Reusable modal form (Collection + Invest)
├── composables/
│   └── useEnquiry.js           # Single submit path for all three forms
├── pages/
│   ├── index.vue               # Homepage            → /
│   ├── about.vue               # About               → /about
│   ├── collection.vue          # The Collection      → /collection
│   ├── invest.vue              # Invest              → /invest
│   ├── contact.vue             # Contact (inline form) → /contact
│   └── explore/
│       ├── index.vue           # Magazine index      → /explore
│       └── [slug].vue          # Article template    → /explore/:slug
├── content/
│   └── explore/
│       └── nerja-slowly.md     # First Explore article
└── public/
    └── robots.txt
```

### Shared navbar & footer

Both live in `components/` and are rendered once by `layouts/default.vue`, so
they appear on — and update across — every page. Navbar links are standardised
to **The Collection · Explore · Invest · Contact** (plus the logo home link and
the "Speak with us" button, which goes to `/contact`). About is linked from the
footer.

---

## Editing page content

Each page is a single `.vue` file in `pages/`. Copy lives directly in the
template; repeated lists (the homepage Mandate, the About reasons, the Invest
points, the Explore grid) are small arrays in that file's `<script setup>` so
they're easy to edit in one place.

### Editing SEO

Every page sets its own title + meta description + Open Graph tags with
`useSeoMeta({ ... })` at the top of `<script setup>`. Edit the strings there.
Article SEO comes from the markdown frontmatter (see below). The site URL used
for the sitemap and canonical tags is `site.url` in `nuxt.config.ts` — **change
it to the production domain before launch.**

---

## Adding an Explore article

Articles are markdown files in `content/explore/`. **The filename is the URL
slug** — `content/explore/ronda-slowly.md` → `/explore/ronda-slowly`.

The fastest way is to copy `nerja-slowly.md` and replace the fields. All content
lives in the frontmatter, which `pages/explore/[slug].vue` renders into the
article layout:

```yaml
---
title: "Article title"
location: "Ronda"                 # shown in the red tag, e.g. "Ronda · Dining"
category: "A Town Guide"
standfirst: "One-line summary under the title."
featuredStand: "Longer summary used if this article is featured on /explore."
heroImage: "https://…"            # full-bleed header image
heroAlt: "Describe the image"
author: "Ignatti Homes"
visited: "Visited in May"         # the small meta line
date: "2026-05-20"                # newest date becomes the /explore featured slot
seo:
  title: "Custom <title> | Ignatti Homes"
  description: "Meta description for search + social."
lead:                             # opening paragraphs (first gets the drop-cap)
  - "First paragraph…"
  - "Second paragraph…"
stayNoteLabel: "Where we stayed"  # the red-ruled note block (optional)
stayNote: "…"
guideRuleLabel: "Eight ways to spend the days"   # the divider label (optional)
guide:                            # numbered sections; image/gradient optional
  - num: "01"
    title: "Section heading"
    text: "Section paragraph…"
    image: "https://…"            # omit image + gradient for a text-only section
    alt: "Describe the image"
    gradient: "linear-gradient(135deg,#9ab0bd,#5b7a88)"   # shown while the image loads
pullQuote: "A single emphasised line near the end."        # optional
closeText: "The closing paragraph."                        # optional
---
```

The new article is live at its URL immediately and, if it has the newest
`date`, becomes the featured article on `/explore`.

> **Note on the Explore grid:** the nine cards in the `/explore` grid and the
> three "More from Explore" cards on an article are currently curated seed cards
> (defined in `pages/explore/index.vue` and `pages/explore/[slug].vue`) and link
> to the live article. Once several real articles exist, swap those arrays for a
> `queryContent('explore')` query to list them automatically.

---

## Forms

All three enquiry forms — Collection ("Request an introduction"), Invest ("Share
your requirements") and Contact — submit through **one** function:
`composables/useEnquiry.js → submitEnquiry()`. Today it resolves successfully so
the inline / modal success states show; there is no backend yet.

To connect a real backend (email service, API route, Formspree, Resend, …), edit
the single marked spot in `composables/useEnquiry.js`:

```js
// TODO: connect the real submission endpoint here, e.g.
//   await $fetch('/api/enquiry', { method: 'POST', body: payload })
```

Every form benefits at once. The Collection and Invest field sets are passed as
`rows` props to `components/EnquiryModal.vue`; the Contact form is inline in
`pages/contact.vue`.

---

## Deployment (Vercel)

Push to a Git repo and import it in Vercel — **no configuration required.** Nuxt
detects Vercel and uses the correct preset automatically.

- Build command: `npm run build` (default)
- Output: handled by the Nuxt Vercel preset
- The whole site is pre-rendered to static HTML at build time (`nitro.prerender`
  with `crawlLinks`), so it serves fast and the sitemap is complete.

Before launch: set `site.url` in `nuxt.config.ts` to the production domain (it
feeds the sitemap, `robots.txt` reference and canonical URLs).
