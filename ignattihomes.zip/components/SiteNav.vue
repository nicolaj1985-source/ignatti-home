<template>
  <header class="site-nav">
    <Logo />

    <nav class="nav-links">
      <NuxtLink to="/collection">The Collection</NuxtLink>
      <NuxtLink to="/explore">Explore</NuxtLink>
      <NuxtLink to="/invest">Invest</NuxtLink>
      <NuxtLink to="/contact">Contact</NuxtLink>
    </nav>

    <NuxtLink class="nav-speak" to="/contact">
      Speak with us
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7M7 7h10v10"/></svg>
    </NuxtLink>
  </header>
</template>

<script setup>
// Canonical navbar — identical on every page. Links are standardised to
// The Collection, Explore, Invest, Contact. NuxtLink adds router-link-active
// automatically, which we use to highlight the current section.
</script>

<style scoped>
.site-nav{
  position:fixed;top:0;left:0;right:0;z-index:100;
  height:72px;padding:0 52px;
  display:flex;align-items:center;justify-content:space-between;
  background:#fff;border-bottom:1px solid var(--line);
}
.nav-links{display:flex;gap:36px}
.nav-links a{font-size:13.5px;font-weight:400;color:var(--ink-2);letter-spacing:.01em;transition:color .2s}
.nav-links a:hover{color:var(--ink)}
.nav-links a.router-link-active{color:var(--ink)}
.nav-speak{
  display:inline-flex;align-items:center;gap:8px;
  background:#fff;color:var(--red);
  border:1px solid var(--red);border-radius:4px;
  font-size:12.5px;font-weight:500;letter-spacing:.05em;
  padding:10px 20px;
  transition:background .22s,color .22s;
}
.nav-speak:hover{background:var(--red);color:#fff}
.nav-speak svg{width:13px;height:13px;transition:transform .2s}
.nav-speak:hover svg{transform:translateX(2px)}

@media(max-width:960px){
  .site-nav{height:64px;padding-left:28px;padding-right:28px}
  .nav-links{display:none}
}
</style>
