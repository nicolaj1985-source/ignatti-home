<template>
  <footer class="site-footer">
    <div class="footer-inner">
      <div class="footer-top">
        <div class="footer-brand">
          <Logo />
          <div class="footer-tag">Managing exceptional properties<br>on the Costa del Sol corridor.</div>
        </div>
        <div>
          <div class="footer-col-title">Navigation</div>
          <nav class="footer-nav">
            <NuxtLink to="/about">About</NuxtLink>
            <NuxtLink to="/collection">The Collection</NuxtLink>
            <NuxtLink to="/explore">Explore</NuxtLink>
            <NuxtLink to="/invest">Invest</NuxtLink>
            <NuxtLink to="/contact">Contact</NuxtLink>
          </nav>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="footer-copy">© 2025 Ignatti Homes. All rights reserved.</div>
        <div class="footer-legal">
          <NuxtLink to="/">Privacy Policy</NuxtLink>
          <NuxtLink to="/">Terms</NuxtLink>
        </div>
      </div>
    </div>
  </footer>
</template>

<script setup>
// Canonical off-white footer — identical on every page.
</script>

<style scoped>
.site-footer{background:#F5F2EE;color:var(--ink);padding:72px 52px 46px}
.footer-inner{max-width:1200px;margin:0 auto}
.footer-top{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:52px;border-bottom:1px solid rgba(26,26,26,.1)}
.footer-tag{font-size:13.5px;font-weight:300;color:var(--ink-2);margin-top:14px;line-height:1.65;max-width:300px}
.footer-col-title{font-size:10px;font-weight:500;letter-spacing:.18em;text-transform:uppercase;color:var(--ink-3);margin-bottom:18px}
.footer-nav{display:flex;flex-direction:column;gap:12px}
.footer-nav a{font-size:13.5px;font-weight:300;color:var(--ink-2);transition:color .2s}
.footer-nav a:hover{color:var(--ink)}
.footer-bottom{display:flex;justify-content:space-between;align-items:center;padding-top:28px}
.footer-copy{font-size:11.5px;color:var(--ink-3);letter-spacing:.04em}
.footer-legal{display:flex;gap:22px}
.footer-legal a{font-size:11.5px;color:var(--ink-3);transition:color .2s;letter-spacing:.03em}
.footer-legal a:hover{color:var(--ink)}

@media(max-width:960px){
  .site-footer{padding:52px 28px 36px}
  .footer-top{flex-direction:column;gap:40px}
  .footer-bottom{flex-direction:column;gap:12px;align-items:flex-start}
}
</style>
