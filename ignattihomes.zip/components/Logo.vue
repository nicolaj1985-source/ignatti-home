<template>
  <NuxtLink class="logo" to="/" aria-label="Ignatti Homes — home">
    <span class="logo-ig">ignatti</span>
    <span class="logo-h">Homes</span>
  </NuxtLink>
</template>

<script setup>
// The wordmark lockup: "ignatti" in DM Serif Display + "Homes" in red small
// caps. Used in both the navbar and the footer; always links home.
</script>

<style scoped>
.logo{display:flex;align-items:baseline;gap:9px}
.logo-ig{font-family:'DM Serif Display',Georgia,serif;font-size:22px;color:var(--ink);letter-spacing:-.01em}
.logo-h{font-family:'Inter',sans-serif;font-size:10px;font-weight:600;letter-spacing:.24em;text-transform:uppercase;color:var(--red)}
</style>
