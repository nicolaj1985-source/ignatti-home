<template>
  <section class="lifestyle" :class="{ compact }">
    <img :src="image" :alt="alt" :style="imgStyle" @error="onError">
    <div class="lifestyle-cap">
      <span class="ls-place">{{ place }}</span>
      <p class="ls-line">{{ line }}</p>
    </div>
  </section>
</template>

<script setup>
// Full-bleed photographic "breather" between editorial sections, with a small
// place eyebrow and an italic serif line over a darkening gradient.
defineProps({
  image: { type: String, required: true },
  alt: { type: String, default: '' },
  place: { type: String, default: '' },
  line: { type: String, default: '' },
  // Optional inline filter overrides (some breaks brighten the photo).
  imgStyle: { type: String, default: '' },
  // The About page uses slightly shorter breaks than the homepage.
  compact: { type: Boolean, default: false },
})

function onError(e) {
  e.target.style.display = 'none'
}
</script>

<style scoped>
.lifestyle{
  position:relative;height:80vh;min-height:460px;max-height:780px;
  overflow:hidden;background:linear-gradient(135deg,#7fc6d8 0%,#3f8fb0 100%);
}
.lifestyle.compact{height:72vh;min-height:440px;max-height:720px}
.lifestyle img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;filter:saturate(1.1) brightness(1.06)}
.lifestyle::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(to top,rgba(8,18,26,.42) 0%,rgba(8,18,26,.08) 48%,transparent 100%);
}
.lifestyle-cap{
  position:relative;z-index:2;height:100%;
  max-width:1200px;margin:0 auto;padding:0 52px 60px;
  display:flex;flex-direction:column;justify-content:flex-end;
}
.ls-place{
  font-size:10.5px;font-weight:500;letter-spacing:.24em;text-transform:uppercase;
  color:rgba(255,255,255,.92);margin-bottom:16px;
  text-shadow:0 1px 14px rgba(0,0,0,.42);
}
.ls-line{
  font-family:'DM Serif Display',Georgia,serif;
  font-size:clamp(1.7rem,3.2vw,2.6rem);font-style:italic;font-weight:400;
  line-height:1.22;letter-spacing:-.01em;color:#fff;max-width:600px;
  text-shadow:0 2px 26px rgba(0,0,0,.5),0 1px 2px rgba(0,0,0,.24);
}

@media(max-width:960px){
  .lifestyle{height:60vh;min-height:380px}
  .lifestyle.compact{height:56vh;min-height:360px}
  .lifestyle-cap{padding-left:28px;padding-right:28px;padding-bottom:44px}
}
</style>
