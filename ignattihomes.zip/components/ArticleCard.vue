<template>
  <NuxtLink class="card" :class="{ compact }" :to="to">
    <div class="card-media" :style="gradient ? { background: gradient } : null">
      <img v-if="image" :src="image" :alt="alt" @error="onError">
    </div>
    <span class="card-tag">{{ tag }}</span>
    <h3 class="card-title">{{ title }}</h3>
    <p class="card-stand">{{ stand }}</p>
  </NuxtLink>
</template>

<script setup>
// Editorial article card used in the Explore index grid and the
// "More from Explore" strip on articles. `compact` matches the slightly
// smaller title/standfirst used in the More strip.
defineProps({
  to: { type: String, default: '#' },
  image: { type: String, default: '' },
  alt: { type: String, default: '' },
  tag: { type: String, default: '' },
  title: { type: String, default: '' },
  stand: { type: String, default: '' },
  gradient: { type: String, default: '' },
  compact: { type: Boolean, default: false },
})

function onError(e) {
  e.target.style.display = 'none'
}
</script>

<style scoped>
.card{display:block;cursor:pointer}
.card-media{position:relative;aspect-ratio:3/2;overflow:hidden;border-radius:6px;margin-bottom:20px;background:linear-gradient(135deg,#cbb9a4,#9a8268)}
.card-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .7s ease}
.card:hover .card-media img{transform:scale(1.05)}
.card-tag{font-size:10px;font-weight:500;letter-spacing:.16em;text-transform:uppercase;color:var(--red);margin-bottom:13px;display:block}
.card-title{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;
  font-size:1.5rem;line-height:1.18;letter-spacing:-.018em;color:var(--ink);margin-bottom:11px;transition:color .22s;
}
.card:hover .card-title{color:var(--red)}
.card-stand{font-size:.97rem;font-weight:300;line-height:1.66;color:var(--ink-2);max-width:360px}

/* "More from Explore" strip — marginally tighter type. */
.card.compact{margin:0}
.card.compact .card-media{margin-bottom:18px}
.card.compact .card-tag{margin-bottom:12px}
.card.compact .card-title{font-size:1.4rem;margin-bottom:10px}
.card.compact .card-stand{font-size:.95rem;line-height:1.64;max-width:none}
</style>
