<template>
  <span class="sec-label"><slot /></span>
</template>

<script setup>
// The small red uppercase eyebrow used above section titles across the site.
// Styling lives in assets/css/main.css (.sec-label) so context overrides
// (e.g. .ih-text .sec-label) reach it.
</script>
