<template>
  <div class="modal-overlay" :class="{ open }" @click.self="close">
    <div class="modal-card">
      <button class="modal-close" aria-label="Close" @click="close">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>

      <!-- FORM -->
      <template v-if="!done">
        <div class="modal-head">
          <span class="sec-label">{{ eyebrow }}</span>
          <div class="modal-rule"></div>
          <h2 class="sec-title">{{ title }}</h2>
          <p class="modal-head-sub">{{ intro }}</p>
        </div>

        <form novalidate @submit.prevent="onSubmit">
          <template v-for="(row, r) in rows" :key="r">
            <div :class="row.length === 2 ? 'mf-row' : null">
              <div v-for="field in row" :key="field.name" class="mf-field">
                <label :for="'mf-' + field.name">{{ field.label }}</label>

                <textarea
                  v-if="field.type === 'textarea'"
                  :id="'mf-' + field.name"
                  :name="field.name"
                  :required="field.required"
                  v-model="form[field.name]"
                ></textarea>

                <select
                  v-else-if="field.type === 'select'"
                  :id="'mf-' + field.name"
                  :name="field.name"
                  :required="field.required"
                  v-model="form[field.name]"
                >
                  <option value="" disabled>{{ field.placeholder || 'Select' }}</option>
                  <option v-for="opt in field.options" :key="opt" :value="opt">{{ opt }}</option>
                </select>

                <input
                  v-else
                  :id="'mf-' + field.name"
                  :type="field.type || 'text'"
                  :name="field.name"
                  :required="field.required"
                  v-model="form[field.name]"
                >
              </div>
            </div>
          </template>

          <div class="mf-actions">
            <button type="submit" class="btn-ig">
              {{ submitLabel }}
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
            </button>
            <p class="mf-reassure">{{ reassure }}</p>
          </div>
        </form>
      </template>

      <!-- SUCCESS -->
      <div v-else class="modal-done">
        <div class="modal-done-h">{{ successTitle }}</div>
        <p>{{ successBody }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref, watch, onMounted, onBeforeUnmount } from 'vue'

// Reusable enquiry modal. Pages drive the fields and copy entirely through
// props, so the same component serves the Collection introduction and the
// Invest requirements briefs. `rows` is an array of rows, each holding one or
// two field descriptors: { name, label, type, options?, placeholder?, required? }.
const props = defineProps({
  open: { type: Boolean, default: false },
  eyebrow: { type: String, default: '' },
  title: { type: String, default: '' },
  intro: { type: String, default: '' },
  rows: { type: Array, default: () => [] },
  submitLabel: { type: String, default: 'Send your enquiry' },
  reassure: { type: String, default: '' },
  successTitle: { type: String, default: 'Thank you.' },
  successBody: { type: String, default: '' },
})

const emit = defineEmits(['update:open'])

// Build the reactive form model from the field descriptors.
const form = reactive({})
props.rows.flat().forEach((field) => {
  if (field && field.name) form[field.name] = ''
})

const done = ref(false)

async function onSubmit() {
  // Routes through the shared composable; success state shows on resolve.
  await submitEnquiry({ ...form })
  done.value = true
}

function close() {
  emit('update:open', false)
}

// Lock body scroll while the modal is open.
watch(
  () => props.open,
  (isOpen) => {
    if (import.meta.client) document.body.style.overflow = isOpen ? 'hidden' : ''
  },
)

function onKey(e) {
  if (e.key === 'Escape' && props.open) close()
}
onMounted(() => window.addEventListener('keydown', onKey))
onBeforeUnmount(() => {
  window.removeEventListener('keydown', onKey)
  if (import.meta.client) document.body.style.overflow = ''
})
</script>

<style scoped>
.modal-overlay{
  position:fixed;inset:0;z-index:200;background:rgba(18,18,18,.62);
  display:flex;align-items:center;justify-content:center;padding:24px;
  opacity:0;pointer-events:none;transition:opacity .28s ease;
}
.modal-overlay.open{opacity:1;pointer-events:all}
.modal-card{
  position:relative;background:var(--off);
  border:1px solid var(--line);border-top:3px solid var(--red);border-radius:6px;
  width:100%;max-width:680px;max-height:90vh;overflow-y:auto;padding:56px 60px 52px;
  transform:translateY(18px);transition:transform .28s ease;
}
.modal-overlay.open .modal-card{transform:translateY(0)}
.modal-close{
  position:absolute;top:20px;right:22px;background:none;border:none;cursor:pointer;
  color:var(--ink-3);padding:6px;display:flex;align-items:center;justify-content:center;transition:color .2s;
}
.modal-close:hover{color:var(--ink)}
.modal-close svg{width:18px;height:18px}
.modal-head{text-align:center;margin-bottom:44px}
.modal-rule{width:32px;height:1px;background:var(--line-2);margin:0 auto 22px}
.modal-head .sec-title{font-size:clamp(1.7rem,3vw,2.3rem);margin-bottom:16px}
.modal-head-sub{font-size:.97rem;font-weight:300;line-height:1.72;color:var(--ink-2);max-width:460px;margin:0 auto}
.mf-row{display:flex;gap:20px}
.mf-row .mf-field{flex:1}
.mf-field{margin-bottom:22px}
.mf-field label{display:block;font-size:10.5px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-3);margin-bottom:10px}
.mf-field input,.mf-field textarea,.mf-field select{
  width:100%;border:1px solid var(--line-2);border-radius:4px;background:#fff;
  font-family:'Inter',sans-serif;font-size:1rem;font-weight:300;color:var(--ink);
  padding:11px 14px;transition:border-color .22s,box-shadow .22s;
}
.mf-field input:focus,.mf-field textarea:focus,.mf-field select:focus{
  outline:none;border-color:var(--red);box-shadow:0 0 0 3px rgba(200,16,46,.07);
}
.mf-field textarea{resize:vertical;min-height:96px;line-height:1.72}
.mf-field select{
  appearance:none;-webkit-appearance:none;cursor:pointer;
  background-image:url("data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%239e9e9e' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
  background-repeat:no-repeat;background-position:right 13px center;background-size:16px;padding-right:40px;
}
.mf-field select:invalid{color:var(--ink-3)}
.mf-actions{margin-top:34px;text-align:center}
.mf-reassure{margin:22px auto 0;max-width:440px;font-size:.86rem;font-weight:300;line-height:1.7;color:var(--ink-3)}
.modal-done{text-align:center;padding:16px 0 8px}
.modal-done-h{font-family:'DM Serif Display',Georgia,serif;font-size:2rem;letter-spacing:-.02em;color:var(--ink);margin-bottom:16px}
.modal-done p{font-size:1rem;font-weight:300;line-height:1.76;color:var(--ink-2)}

@media(max-width:680px){
  .modal-card{padding:44px 28px 40px}
  .mf-row{flex-direction:column;gap:0}
}
</style>
