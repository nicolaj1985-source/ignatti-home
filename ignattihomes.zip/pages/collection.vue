<template>
  <div>
    <!-- HERO -->
    <section class="coll-hero">
      <img class="coll-hero-img" src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=2400&q=80&auto=format&fit=crop" alt="A Mediterranean villa with an infinity pool above the coast at dusk" @error="(e) => (e.target.style.display = 'none')">
      <div class="coll-hero-inner">
        <SectionLabel>The Collection</SectionLabel>
        <h1>The collection is private. <em>By design.</em></h1>
        <p class="coll-hero-sub">The villas in our care are not found on the open platforms. They are shown privately, by request, to the guests they are right for — a personal introduction, never a search result.</p>
      </div>
      <div class="coll-scroll">
        <a href="#" @click.prevent="showModal = true">
          Request an introduction
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M6 13l6 6 6-6"/></svg>
        </a>
      </div>
    </section>

    <!-- STATEMENT -->
    <section class="coll-statement">
      <div class="coll-statement-inner">
        <SectionLabel>Why nothing is listed</SectionLabel>
        <h2 class="sec-title">The platforms show everything to everyone. <em>We do the opposite.</em></h2>
        <div class="sec-body">
          <p>Search any booking site and the same homes appear to anyone who enters the same dates. Everything is visible. Nothing is held back. The villa that greets you at the door is the one a hundred others scrolled past an hour before.</p>
          <p>Ignatti Homes works the other way. A property in our care is not published — it is offered privately, to the guest it suits. You tell us what you are looking for. We introduce you to the home that answers it. What you receive is not a result on a page, but an introduction to somewhere most people will never be shown.</p>
          <p>The discretion is the point. It is what lets a stay feel like more than a transaction — and it is the same discretion that protects the owners who place their homes with us. The open platforms cannot offer it. They are built to do the opposite.</p>
        </div>
      </div>
    </section>

    <!-- CLOSE CTA -->
    <section class="coll-close">
      <div class="coll-close-inner">
        <SectionLabel>By request</SectionLabel>
        <h2 class="sec-title">If you would like an <em>introduction.</em></h2>
        <p class="coll-close-sub">A handful of properties are accepted each year. The same selectivity applies to every stay. Tell us what you are looking for — a person will read it and respond.</p>
        <button class="btn-ig" @click="showModal = true">
          Request an introduction
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </button>
      </div>
    </section>

    <!-- ENQUIRY MODAL -->
    <EnquiryModal
      v-model:open="showModal"
      eyebrow="By request"
      title="Tell us what you are looking for."
      intro="Every enquiry reaches a person, not a booking system. You will hear back from someone who has read what you wrote."
      :rows="rows"
      submit-label="Send your enquiry"
      reassure="Every enquiry is read and answered personally. Nothing you share is listed, sold, or added to a mailing list."
      success-title="Thank you."
      success-body="Your enquiry is with us. Someone will read what you have written and reply personally — usually within a day."
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'

useSeoMeta({
  title: 'The Collection — Ignatti Homes',
  description:
    'The villas in our care are not listed on the open platforms. They are shown privately, by request, to the guests they are right for — a personal introduction, never a search result.',
  ogTitle: 'The Collection — Ignatti Homes',
  ogDescription: 'The collection is private. By design.',
  ogType: 'website',
})

const showModal = ref(false)

const rows = [
  [
    { name: 'name', label: 'Name', type: 'text', required: true },
    { name: 'email', label: 'Email', type: 'email', required: true },
  ],
  [
    { name: 'when', label: 'When are you thinking of visiting', type: 'text' },
    { name: 'guests', label: 'How many guests', type: 'text' },
  ],
  [{ name: 'matters', label: 'What matters most to you about where you stay', type: 'textarea' }],
  [{ name: 'heard', label: 'How did you hear about Ignatti Homes', type: 'text' }],
]
</script>

<style scoped>
/* ===== HERO (full screen, private window) ===== */
.coll-hero{
  position:relative;min-height:100vh;
  display:flex;align-items:center;justify-content:center;text-align:center;overflow:hidden;
  background:linear-gradient(160deg,#2b3a44 0%,#141d24 100%);
}
.coll-hero-img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block}
.coll-hero::after{
  content:'';position:absolute;inset:0;z-index:1;
  background:linear-gradient(to bottom,rgba(12,18,23,.52) 0%,rgba(12,18,23,.30) 42%,rgba(12,18,23,.64) 100%);
}
.coll-hero-inner{position:relative;z-index:2;max-width:820px;padding:90px 40px 0}
.coll-hero h1{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;
  font-size:clamp(2.7rem,5.6vw,4.4rem);line-height:1.07;letter-spacing:-.022em;
  color:#fff;margin-bottom:26px;text-shadow:0 2px 34px rgba(0,0,0,.46);
}
.coll-hero h1 em{font-style:italic}
.coll-hero-sub{
  font-size:1.14rem;font-weight:300;line-height:1.72;
  color:rgba(255,255,255,.93);max-width:560px;margin:0 auto;text-shadow:0 1px 20px rgba(0,0,0,.42);
}
.coll-scroll{position:absolute;left:0;right:0;bottom:40px;z-index:2;display:flex;flex-direction:column;align-items:center;gap:12px}
.coll-scroll a{
  display:flex;flex-direction:column;align-items:center;gap:12px;
  font-size:10px;font-weight:500;letter-spacing:.22em;text-transform:uppercase;
  color:rgba(255,255,255,.86);text-shadow:0 1px 14px rgba(0,0,0,.4);transition:color .2s;cursor:pointer;
}
.coll-scroll a:hover{color:#fff}
.coll-scroll svg{width:20px;height:20px;animation:collbob 2.4s ease-in-out infinite}
@keyframes collbob{0%,100%{transform:translateY(0)}50%{transform:translateY(7px)}}

/* ===== STATEMENT ===== */
.coll-statement{padding:132px 52px;text-align:center}
.coll-statement-inner{max-width:820px;margin:0 auto}
.coll-statement .sec-title{max-width:740px;margin-left:auto;margin-right:auto}
.coll-statement .sec-body{max-width:660px;margin:0 auto;text-align:left}

/* ===== CLOSE CTA ===== */
.coll-close{padding:124px 52px 144px;border-top:1px solid var(--line);text-align:center}
.coll-close-inner{max-width:640px;margin:0 auto}
.coll-close .sec-title{margin-bottom:20px}
.coll-close-sub{font-size:1.02rem;font-weight:300;line-height:1.78;color:var(--ink-2);max-width:480px;margin:0 auto 44px}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .coll-statement,.coll-close{padding-left:28px;padding-right:28px}
  .coll-hero-inner{padding:80px 28px 0}
  .coll-statement{padding-top:88px;padding-bottom:88px}
  .coll-close{padding-top:92px;padding-bottom:104px}
}
</style>
