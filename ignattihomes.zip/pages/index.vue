<template>
  <div>
    <!-- HERO -->
    <section class="hero" :class="{ loaded: heroLoaded }">
      <div class="hero-bg"></div>
      <div class="hero-overlay"></div>
      <div class="hero-inner">
        <div class="hero-label">Costa del Sol &nbsp;·&nbsp; Villa Management</div>
        <h1 class="hero-title">Your villa, managed to the standard it deserves.</h1>
        <NuxtLink class="hero-cta" to="/contact">
          Speak with us
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </NuxtLink>
      </div>
    </section>

    <!-- PHILOSOPHY -->
    <section class="philosophy" id="philosophy">
      <div class="philosophy-inner">
        <SectionLabel>The Philosophy</SectionLabel>
        <h2 class="sec-title">We manage a small number of properties.<br><em>Deliberately.</em></h2>
        <div class="sec-body">
          <p>We manage a small number of properties. Not because we lack the capacity to manage more, but because we choose not to. Every home in our portfolio receives our full attention — and full attention is a finite resource.</p>
          <p>Ignatti Homes was built on a single conviction: that an exceptional property deserves an operator who treats it as such. That means decisions made on long-term asset value, not short-term yield. It means turning down the wrong enquiries, choosing guests with the same care you'd choose a tenant, and communicating with owners as if we own the place ourselves.</p>
          <p>We don't think of ourselves as a management company. We think of ourselves as the people you trust with something that matters.</p>
        </div>
      </div>
    </section>

    <!-- LIFESTYLE BREAK -->
    <LifestyleBreak
      image="https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=2200&q=85"
      alt="Turquoise infinity pool in full Mediterranean sun"
      place="Benahavís &nbsp;·&nbsp; Golden hour"
      line="The light here was the first thing that made you stay."
    />

    <!-- THE MANDATE -->
    <section class="mandate" id="mandate">
      <div class="mandate-inner">
        <div class="mandate-intro">
          <SectionLabel>The Mandate</SectionLabel>
          <h2 class="sec-title">What you stop thinking about<br>the day you join.</h2>
          <div class="sec-body">
            <p>When we take on a property, the owner stops worrying about it. Not because they have less control — but because they have more confidence. These are the things they no longer need to think about.</p>
          </div>
        </div>

        <div class="mandate-list">
          <div v-for="item in mandate" :key="item.n" class="mandate-item">
            <div class="mn">{{ item.n }}</div>
            <div class="mandate-txt">
              <div class="mt">{{ item.t }}</div>
              <div class="ms">{{ item.s }}</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- LIFESTYLE BREAK -->
    <LifestyleBreak
      image="https://images.unsplash.com/photo-1540541338287-41700207dee6?w=2200&q=85"
      alt="The Mediterranean coast in full daylight"
      img-style="filter:saturate(1.18) brightness(1.13) contrast(.98)"
      place="The coast &nbsp;·&nbsp; Costa del Sol"
      line="The life your property was always meant to give you."
    />

    <!-- THE COLLECTION -->
    <section class="collection" id="collection">
      <div class="collection-inner">
        <div class="collection-hd">
          <div>
            <SectionLabel>The Collection</SectionLabel>
            <h2 class="sec-title" style="margin-bottom:0">Properties in our care.</h2>
          </div>
          <p class="coll-sub">A curated selection of exceptional villas on the Costa del Sol corridor. Each one chosen for a reason.</p>
        </div>
        <div class="prop-grid">
          <div v-for="prop in properties" :key="prop.loc" class="prop-card">
            <img :src="prop.img" :alt="'Villa in ' + prop.loc" @error="(e) => (e.target.style.opacity = 0)">
            <div class="prop-tag">Under management</div>
            <div class="prop-overlay">
              <div class="prop-loc">{{ prop.loc }}</div>
              <div class="prop-type">{{ prop.type }}</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CONTACT — homepage close -->
    <section class="contact" id="contact">
      <div class="contact-inner">
        <SectionLabel>Begin a Conversation</SectionLabel>
        <h2 class="sec-title">If your property fits,<br>we'd like to hear from you.</h2>
        <p class="contact-sub">We take on very few properties each year. If you believe yours belongs in the portfolio, the first step is a conversation. No obligation. No sales process.</p>
        <NuxtLink class="contact-link" to="/contact">
          Begin a conversation
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </NuxtLink>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

useSeoMeta({
  title: 'Ignatti Homes — Villa Management on the Costa del Sol',
  description:
    'We manage a small number of exceptional villas on the Costa del Sol corridor — deliberately. Full attention, protected rates, and owners who can finally stop thinking about it.',
  ogTitle: 'Ignatti Homes — Villa Management on the Costa del Sol',
  ogDescription:
    'A deliberately small portfolio of exceptional villas, managed to the standard they deserve.',
  ogType: 'website',
})

// Triggers the slow hero zoom-out once the page is mounted.
const heroLoaded = ref(false)
onMounted(() => {
  heroLoaded.value = true
})

const mandate = [
  { n: '01', t: 'Revenue management and pricing', s: 'Calibrated to the market, adjusted continuously. We protect rate integrity as well as occupancy — short-term gains that damage the asset are not gains we pursue.' },
  { n: '02', t: 'Guest selection and vetting', s: 'We choose guests as carefully as we choose properties. Every booking is reviewed by a person. Standards are consistent and non-negotiable.' },
  { n: '03', t: 'Property maintenance and care', s: 'Preventive, not reactive. Your property is inspected before and after every stay. Issues are resolved before they become something you hear about.' },
  { n: '04', t: 'Legal compliance and licensing', s: 'Tourism licensing, local registration, and tax compliance — handled in full and kept current. We don\'t let administrative failure become your liability.' },
  { n: '05', t: '24-hour guest support', s: 'From arrival to departure, guests have a direct line to us. You don\'t hear from them at 11pm. You don\'t hear from us either, unless it matters.' },
  { n: '06', t: 'Monthly owner reporting', s: 'Clear, honest numbers. Revenue, occupancy, costs, and commentary — every month, without being asked. We don\'t hide the difficult months.' },
]

const properties = [
  { loc: 'Benahavís', type: 'Villa  ·  5 bedrooms', img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80' },
  { loc: 'La Zagaleta', type: 'Villa  ·  7 bedrooms', img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80' },
  { loc: 'Golden Mile', type: 'Villa  ·  4 bedrooms', img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80' },
]
</script>

<style scoped>
/* ===== HERO ===== */
.hero{height:100vh;min-height:640px;position:relative;overflow:hidden;background:#cfe3ef}
.hero-bg{
  position:absolute;inset:0;
  background-image:url('https://media.inmobalia.com/imgV1/B95mbh8olwFQm~uCUaVOI2kQT0hb0a8sZ9turUNfnwtvuccYCzs0YVPfPbfkc2VnnN1JFDpiVdhTScitksoZQd_Tif4X1AqZwLqyEo84UxJGp2hhgjHPrG2iF0QYN5AQHpCSJPnl~Vc_L4iBWXNnZuYlvoTBNTxEWDherc_CnwSggNhwLSDYhrmmEyxeBDiPv7cfKhSOs3VXO06Zp3vWmwX80nh_IGSRaMGV6n1GS~_eJYFx1977tI~KqjbnL9Ymrw49uRK3CAXyhxtAUU_Q7NwPOVAzVBBEbrX_L55pz0KhLlUnmbULVf_1ATXuQQy6MKOs_JnDSJkznE_JVzfVvBbJVg3LRpDckQa7rfKPm6f6CoIqcyILs1lObP1mK2qXCe5uJ4WknBXW0oAiE77obQ_YonRWug--.png');
  background-size:cover;background-position:center 50%;
  transform:scale(1.05);transition:transform 11s ease-out;
  filter:saturate(1.07) brightness(1.04);
}
.hero.loaded .hero-bg{transform:scale(1)}
.hero-overlay{
  position:absolute;inset:0;
  background:linear-gradient(to top, rgba(0,0,0,.16) 0%, rgba(0,0,0,.1) 24%, rgba(0,0,0,.02) 46%, transparent 60%);
}
.hero-inner{
  position:relative;z-index:1;height:100%;
  max-width:1200px;margin:0 auto;padding:0 52px 92px;
  display:flex;flex-direction:column;justify-content:flex-end;
}
.hero-label{
  font-size:11px;font-weight:500;letter-spacing:.22em;text-transform:uppercase;
  color:var(--red);margin-bottom:20px;text-shadow:0 1px 12px rgba(0,0,0,.32);
}
.hero-title{
  font-family:'DM Serif Display',Georgia,serif;
  font-size:clamp(3.4rem,6.6vw,5.6rem);
  font-weight:400;line-height:1.05;letter-spacing:-.03em;
  color:#fff;max-width:840px;margin-bottom:34px;
  text-shadow:0 2px 30px rgba(0,0,0,.42),0 1px 2px rgba(0,0,0,.18);
}
.hero-cta{
  display:inline-flex;align-items:center;gap:9px;
  background:#fff;color:var(--red);border:1px solid var(--red);border-radius:4px;
  font-size:13px;font-weight:500;letter-spacing:.05em;
  padding:13px 26px;width:fit-content;transition:background .22s,color .22s;
}
.hero-cta:hover{background:var(--red);color:#fff}
.hero-cta svg{width:14px;height:14px;transition:transform .2s}
.hero-cta:hover svg{transform:translateX(3px)}

/* ===== PHILOSOPHY ===== */
.philosophy{padding:112px 52px}
.philosophy-inner{max-width:680px;margin:0 auto}

/* ===== THE MANDATE ===== */
.mandate{padding:116px 52px}
.mandate-inner{max-width:760px;margin:0 auto}
.mandate-intro{margin-bottom:68px}
.mandate-list{border-top:1px solid var(--line-2)}
.mandate-item{
  display:grid;grid-template-columns:72px 1fr;gap:0;
  padding:52px 0;border-bottom:1px solid var(--line);align-items:start;
}
.mandate-item:last-child{border-bottom:none}
.mn{font-family:'DM Serif Display',Georgia,serif;font-size:1.45rem;font-style:italic;color:var(--red);padding-top:3px}
.mandate-txt .mt{font-size:1.04rem;font-weight:500;color:var(--ink);margin-bottom:12px;letter-spacing:-.012em;line-height:1.4}
.mandate-txt .ms{font-size:1rem;font-weight:300;line-height:1.86;color:var(--ink-2)}

/* ===== THE COLLECTION ===== */
.collection{padding:112px 52px}
.collection-inner{max-width:1320px;margin:0 auto}
.collection-hd{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:56px}
.coll-sub{font-size:.98rem;font-weight:300;line-height:1.72;color:var(--ink-2);max-width:320px;text-align:right}
.prop-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px}
.prop-card{position:relative;overflow:hidden;aspect-ratio:3/4;background:#c2bdb5;cursor:pointer}
.prop-card img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .7s cubic-bezier(.25,.46,.45,.94);filter:saturate(1.07) brightness(1.03)}
.prop-card:hover img{transform:scale(1.05)}
.prop-overlay{
  position:absolute;inset:0;
  background:linear-gradient(to top, rgba(0,0,0,.62) 0%, rgba(0,0,0,.04) 58%);
  display:flex;flex-direction:column;justify-content:flex-end;padding:38px 32px;
}
.prop-loc{font-family:'DM Serif Display',Georgia,serif;font-size:1.85rem;line-height:1.1;color:#fff;margin-bottom:7px;letter-spacing:-.015em}
.prop-type{font-size:11.5px;font-weight:400;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.6)}
.prop-tag{
  position:absolute;top:18px;left:0;
  font-size:10px;font-weight:600;letter-spacing:.16em;text-transform:uppercase;
  background:var(--red);color:#fff;padding:5px 14px 5px 18px;
}

/* ===== CONTACT — homepage close ===== */
.contact{padding:132px 52px 140px;border-top:1px solid var(--line);text-align:center}
.contact-inner{max-width:680px;margin:0 auto}
.contact .sec-title{margin-bottom:34px}
.contact-sub{font-size:1.02rem;font-weight:300;line-height:1.78;color:var(--ink-2);max-width:520px;margin:0 auto 40px}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .hero-inner,.philosophy,.mandate,.collection,.contact{padding-left:28px;padding-right:28px}
  .hero-inner{padding-bottom:64px}
  .hero-title{font-size:clamp(2.6rem,8vw,3.7rem)}
  .philosophy{padding-top:80px;padding-bottom:80px}
  .mandate,.collection{padding-top:80px;padding-bottom:80px}
  .contact{padding-top:96px;padding-bottom:104px}
  .mandate-item{padding:40px 0}
  .prop-grid{grid-template-columns:1fr;gap:18px}
  .prop-card{aspect-ratio:4/3}
  .collection-hd{flex-direction:column;align-items:flex-start;gap:12px}
  .coll-sub{text-align:left;max-width:100%}
}
</style>
