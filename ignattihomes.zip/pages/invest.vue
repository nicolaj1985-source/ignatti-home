<template>
  <div>
    <!-- HERO -->
    <section class="invest-hero">
      <div class="ih-text">
        <SectionLabel>Invest</SectionLabel>
        <h1>Inside knowledge of a market that <em>rarely shares it.</em></h1>
        <p class="ih-stand">Ignatti Homes sources Costa del Sol property for a small number of investors. Because we operate what we recommend, we advise on real performance — not listing optimism. You tell us the brief; we come back with what fits.</p>
        <div class="ih-actions">
          <button class="btn-ig" @click="showModal = true">
            Share your requirements
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </button>
        </div>
      </div>
      <div class="ih-media">
        <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1800&q=82&auto=format&fit=crop" alt="A modern Costa del Sol villa, clean architectural lines" @error="(e) => (e.target.style.display = 'none')">
      </div>
    </section>

    <!-- POSITIONING STATEMENT -->
    <section class="invest-statement">
      <div class="invest-statement-inner">
        <SectionLabel>How we work</SectionLabel>
        <h2 class="sec-title">We are not an estate agent. <em>We are the operator.</em></h2>
        <div class="sec-body">
          <p>Most property advice on the Costa del Sol comes from people who earn their fee at the point of sale and move on after it. Their incentive ends with the transaction. Ours begins there — because in most cases, the firm advising you on a purchase is the one that will run the property once it is yours.</p>
          <p>That changes what we are able to tell you. We see the booking calendars, the nightly rates that actually clear, the running costs a brochure leaves out. When we put a property in front of you, the projection attached to it is built from operational data — not from the optimism of a listing.</p>
        </div>

        <blockquote class="invest-quote">
          <span class="iq-mark"></span>
          <p>We don't sell properties. We operate them. When we recommend one, it's because we know what it earns — not what it's listed for.</p>
        </blockquote>

        <div class="sec-body">
          <p>We work with a small number of investors at a time, and we source to a brief rather than a catalogue. You set the capacity, the objective, and the horizon. We come back only when something genuinely matches it — and we say so plainly when nothing does.</p>
        </div>
      </div>
    </section>

    <!-- HOW IT WORKS -->
    <section class="invest-how">
      <div class="invest-how-inner">
        <SectionLabel>What working with us looks like</SectionLabel>
        <h2 class="sec-title">Four things that make the difference.</h2>
        <p class="invest-how-sub">No icons, no catalogue, no pressure. A narrow service, done with information most advisers do not have.</p>

        <div class="invest-list">
          <div v-for="item in points" :key="item.h" class="il-item">
            <div class="il-h">{{ item.h }}</div>
            <div class="il-p">{{ item.p }}</div>
          </div>
        </div>
      </div>
    </section>

    <!-- REQUIREMENTS CTA -->
    <section class="invest-cta">
      <div class="invest-cta-inner">
        <SectionLabel>Share your requirements</SectionLabel>
        <h2 class="sec-title">Tell us what you are looking for.</h2>
        <p class="invest-cta-sub">A person reviews every brief and responds with opportunities matched to it — never an automated list. If your requirements are clear, the first reply usually is too.</p>
        <button class="btn-ig" @click="showModal = true">
          Share your requirements
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </button>
      </div>
    </section>

    <!-- REQUIREMENTS MODAL -->
    <EnquiryModal
      v-model:open="showModal"
      eyebrow="Your requirements"
      title="Tell us what you are looking for."
      intro="Every brief is read by a person, not a system. The more you tell us, the more precisely we can match."
      :rows="rows"
      submit-label="Share your requirements"
      reassure="Every brief is reviewed personally and answered with matched opportunities. Nothing you share is listed, sold, or added to a mailing list."
      success-title="Thank you."
      success-body="Your brief is with us. A person will review it and come back to you with opportunities that match — usually within a day or two."
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'

useSeoMeta({
  title: 'Invest — Ignatti Homes',
  description:
    'Inside knowledge of a market that rarely shares it. We operate what we recommend, so we advise on real performance — not listing optimism. Sourced to your brief, not a catalogue.',
  ogTitle: 'Invest — Ignatti Homes',
  ogDescription: 'We are not an estate agent. We are the operator.',
  ogType: 'website',
})

const showModal = ref(false)

const points = [
  { h: 'We source to your brief.', p: 'Not a catalogue to scroll. You set the capacity, the objective, and the locations; we return a short list of opportunities that fit — and nothing that does not. The filtering is the work, and we do it before anything reaches you.' },
  { h: 'We know the real numbers.', p: 'Because we operate properties like the ones we recommend, our projections come from booking data and settled costs — what a home actually clears across a year, not the figure a sales listing leads with.' },
  { h: 'We stay involved after the purchase.', p: 'The same firm that helps you buy can run the property once it is yours. Our advice is therefore measured against how the asset performs over the years you hold it, not against closing the deal.' },
  { h: 'We are selective about the brief.', p: 'We take on a limited number of investors, and we decline the briefs we cannot serve well. A narrow focus is the reason the advice is worth having — and the reason we can give it our full attention.' },
]

const rows = [
  [
    { name: 'name', label: 'Name', type: 'text', required: true },
    { name: 'email', label: 'Email', type: 'email', required: true },
  ],
  [
    { name: 'capacity', label: 'Investment capacity', type: 'select', required: true, placeholder: 'Select a range', options: ['Under €500k', '€500k – €1M', '€1M – €3M', '€3M+'] },
    { name: 'type', label: 'Property type', type: 'select', required: true, placeholder: 'Select', options: ['Villa', 'Apartment', 'Either'] },
  ],
  [
    { name: 'objective', label: 'Primary objective', type: 'select', required: true, placeholder: 'Select', options: ['Rental yield', 'Capital appreciation', 'Personal use + rental'] },
    { name: 'timeline', label: 'Timeline', type: 'select', required: true, placeholder: 'Select', options: ['Actively looking', '3 – 6 months', '12 months+'] },
  ],
  [{ name: 'locations', label: 'Preferred locations on the corridor', type: 'text' }],
  [{ name: 'notes', label: 'Anything else about what you are looking for', type: 'textarea' }],
]
</script>

<style scoped>
/* ===== HERO (calm split) ===== */
.invest-hero{display:grid;grid-template-columns:1fr 1fr;min-height:90vh}
.ih-text{display:flex;flex-direction:column;justify-content:center;padding:128px 60px 84px;border-right:1px solid var(--line)}
.ih-text h1{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;
  font-size:clamp(2.5rem,3.9vw,3.7rem);line-height:1.08;letter-spacing:-.026em;color:var(--ink);margin-bottom:28px;max-width:560px;
}
.ih-text h1 em{font-style:italic}
.ih-stand{font-size:1.12rem;font-weight:300;line-height:1.72;color:var(--ink-2);max-width:500px;margin-bottom:40px}
.ih-actions{display:flex;align-items:center;gap:0}
.ih-media{position:relative;min-height:90vh;overflow:hidden;background:linear-gradient(150deg,#3a4148 0%,#1d2227 100%)}
.ih-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}

/* ===== STATEMENT ===== */
.invest-statement{padding:132px 52px;text-align:center}
.invest-statement-inner{max-width:820px;margin:0 auto}
.invest-statement .sec-title{max-width:720px;margin:0 auto 28px}
.invest-statement .sec-body{max-width:660px;margin:0 auto;text-align:left}
.invest-quote{margin:60px auto;max-width:780px}
.invest-quote .iq-mark{display:block;width:34px;height:2px;background:var(--red);margin:0 auto 28px}
.invest-quote p{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;font-style:italic;
  font-size:clamp(1.6rem,3vw,2.35rem);line-height:1.3;letter-spacing:-.015em;color:var(--ink);
}

/* ===== HOW IT WORKS (structured list) ===== */
.invest-how{padding:120px 52px;border-top:1px solid var(--line)}
.invest-how-inner{max-width:980px;margin:0 auto}
.invest-how .sec-title{max-width:760px;margin-bottom:18px}
.invest-how-sub{font-size:1.04rem;font-weight:300;line-height:1.76;color:var(--ink-2);max-width:560px}
.invest-list{margin-top:58px;border-top:1px solid var(--line-2)}
.il-item{
  padding:46px 0;border-bottom:1px solid var(--line);
  display:grid;grid-template-columns:.85fr 1.15fr;gap:48px;align-items:start;
}
.il-item:last-child{border-bottom:none}
.il-h{font-family:'DM Serif Display',Georgia,serif;font-weight:400;font-size:1.5rem;line-height:1.18;letter-spacing:-.018em;color:var(--ink)}
.il-p{font-size:1.02rem;font-weight:300;line-height:1.82;color:var(--ink-2)}

/* ===== CTA ===== */
.invest-cta{padding:124px 52px 140px;border-top:1px solid var(--line);background:var(--off);text-align:center}
.invest-cta-inner{max-width:640px;margin:0 auto}
.invest-cta .sec-title{margin-bottom:22px}
.invest-cta-sub{font-size:1.02rem;font-weight:300;line-height:1.78;color:var(--ink-2);max-width:500px;margin:0 auto 44px}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .invest-statement,.invest-how,.invest-cta{padding-left:28px;padding-right:28px}
  .invest-hero{grid-template-columns:1fr;min-height:0}
  .ih-text{padding:116px 28px 64px;border-right:none;border-bottom:1px solid var(--line);order:2}
  .ih-media{min-height:46vh;order:1}
  .invest-statement{padding-top:88px;padding-bottom:88px}
  .invest-how{padding-top:84px;padding-bottom:84px}
  .il-item{grid-template-columns:1fr;gap:14px;padding:38px 0}
  .invest-cta{padding-top:92px;padding-bottom:104px}
}
</style>
