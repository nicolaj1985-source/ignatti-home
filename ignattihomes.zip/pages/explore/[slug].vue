<template>
  <article v-if="doc">
    <!-- ARTICLE HEADER -->
    <header class="art-head">
      <div class="art-head-inner">
        <NuxtLink class="art-back" to="/explore">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 18l-6-6 6-6"/></svg>
          Explore
        </NuxtLink>
        <span class="art-tag">{{ [doc.location, doc.category].filter(Boolean).join(' · ') }}</span>
        <h1 class="art-title">{{ doc.title }}</h1>
        <p class="art-stand">{{ doc.standfirst }}</p>
        <p class="art-meta">Words by <span>{{ doc.author }}</span> · {{ doc.visited }}</p>
      </div>
    </header>

    <!-- HERO IMAGE -->
    <div class="art-hero-media">
      <img :src="doc.heroImage" :alt="doc.heroAlt" @error="(e) => (e.target.style.display = 'none')">
    </div>

    <!-- BODY -->
    <div class="art-body">
      <div class="art-lead">
        <p v-for="(para, i) in doc.lead" :key="i">{{ para }}</p>
      </div>

      <div v-if="doc.stayNote" class="art-note">
        <span class="an-k">{{ doc.stayNoteLabel || 'Where we stayed' }}</span>
        <p>{{ doc.stayNote }}</p>
      </div>
    </div>

    <!-- GUIDE SECTIONS -->
    <div v-if="doc.guideRuleLabel" class="body-rule">
      <span class="br-k">{{ doc.guideRuleLabel }}</span><span class="br-l"></span>
    </div>

    <div class="guide">
      <div v-for="item in doc.guide" :key="item.num" class="guide-item">
        <div class="gi-head">
          <span class="gi-num">{{ item.num }}</span>
          <h2 class="gi-h">{{ item.title }}</h2>
        </div>
        <p class="gi-p">{{ item.text }}</p>
        <div v-if="item.image" class="gi-media" :style="item.gradient ? { background: item.gradient } : null">
          <img :src="item.image" :alt="item.alt" @error="(e) => (e.target.style.display = 'none')">
        </div>
      </div>
    </div>

    <!-- PULL QUOTE -->
    <div v-if="doc.pullQuote" class="pull">
      <span class="pull-mark"></span>
      <p>{{ doc.pullQuote }}</p>
    </div>

    <!-- CLOSE -->
    <div v-if="doc.closeText" class="art-close">
      <p>{{ doc.closeText }}</p>
    </div>

    <!-- MORE FROM EXPLORE -->
    <section class="more">
      <div class="more-inner">
        <div class="more-rule"><span class="mr-k">More from Explore</span><span class="mr-l"></span></div>
        <div class="more-grid">
          <ArticleCard
            v-for="card in more"
            :key="card.title"
            compact
            to="/explore/nerja-slowly"
            :image="card.image"
            :alt="card.alt"
            :tag="card.tag"
            :title="card.title"
            :stand="card.stand"
            :gradient="card.gradient"
          />
        </div>
      </div>
    </section>
  </article>
</template>

<script setup>
const route = useRoute()

// Fetch the article markdown for this slug from Nuxt Content.
const { data: doc } = await useAsyncData('article-' + route.params.slug, () =>
  queryContent('explore', String(route.params.slug)).findOne(),
)

if (!doc.value) {
  throw createError({ statusCode: 404, statusMessage: 'Article not found', fatal: true })
}

useSeoMeta({
  title: doc.value.seo?.title || `${doc.value.title} — Ignatti Homes`,
  description: doc.value.seo?.description || doc.value.standfirst,
  ogTitle: doc.value.seo?.title || doc.value.title,
  ogDescription: doc.value.seo?.description || doc.value.standfirst,
  ogImage: doc.value.heroImage,
  ogType: 'article',
})

// Static related cards for the "More from Explore" strip (mirrors the
// prototype). Wire to real related articles once more exist in content/.
const more = [
  { tag: 'Ronda · Where to Stay', title: 'The hotel we keep returning to', stand: 'A converted palace above the gorge. We have stayed four times. Here is why we ask for the same room.', image: 'https://images.unsplash.com/photo-1455587734955-081b22074882?w=1100&q=80&auto=format&fit=crop', alt: 'A palace hotel above the gorge in Ronda', gradient: 'linear-gradient(135deg,#cbb9a4,#8a6f52)' },
  { tag: 'Frigiliana · A Town Guide', title: 'The white town, before the buses', stand: 'Fifteen minutes from Nerja and a century away. Walk it early, while it still belongs to the people who live there.', image: 'https://images.unsplash.com/photo-1591792702338-78bc5a0c4c80?w=1100&q=80&auto=format&fit=crop', alt: 'A white street in Frigiliana', gradient: 'linear-gradient(135deg,#cdbfae,#9a8268)' },
  { tag: 'Cómpeta · Dining', title: 'Dinner at the end of the road', stand: 'A mountain village, a single very good kitchen, and a drive home under the stars. Worth every kilometre.', image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1100&q=80&auto=format&fit=crop', alt: 'A mountain village dining room', gradient: 'linear-gradient(135deg,#d8a47f,#b5754f)' },
]
</script>

<style scoped>
/* ===== ARTICLE HEADER ===== */
.art-head{padding:150px 52px 44px;text-align:center}
.art-head-inner{max-width:760px;margin:0 auto}
.art-back{display:inline-flex;align-items:center;gap:8px;font-size:11px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-3);margin-bottom:30px;transition:color .2s}
.art-back:hover{color:var(--red)}
.art-back svg{width:13px;height:13px}
.art-tag{display:block;font-size:11px;font-weight:500;letter-spacing:.18em;text-transform:uppercase;color:var(--red);margin-bottom:22px}
.art-title{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;
  font-size:clamp(2.7rem,5.6vw,4.4rem);line-height:1.05;letter-spacing:-.026em;color:var(--ink);margin-bottom:26px;
}
.art-stand{font-size:1.2rem;font-weight:300;line-height:1.6;color:var(--ink-2);max-width:560px;margin:0 auto 30px}
.art-meta{font-size:12px;font-weight:400;letter-spacing:.06em;color:var(--ink-3);text-transform:uppercase}
.art-meta span{color:var(--red)}

/* ===== HERO IMAGE ===== */
.art-hero-media{position:relative;width:100%;height:clamp(360px,64vh,640px);overflow:hidden;background:linear-gradient(135deg,#cbb9a4,#8a6f52)}
.art-hero-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}

/* ===== BODY ===== */
.art-body{max-width:860px;margin:0 auto;padding:84px 52px 40px}
.art-lead p{font-size:1.24rem;font-weight:300;line-height:1.74;color:var(--ink);margin-bottom:24px}
.art-lead p:first-child::first-letter{
  font-family:'DM Serif Display',Georgia,serif;float:left;font-size:4.4rem;line-height:.84;padding:6px 14px 0 0;color:var(--red);
}
.art-note{margin:46px 0 10px;padding:30px 34px;background:var(--off);border-left:2px solid var(--red);border-radius:4px}
.art-note .an-k{font-size:10.5px;font-weight:500;letter-spacing:.18em;text-transform:uppercase;color:var(--red);margin-bottom:12px;display:block}
.art-note p{font-size:1.02rem;font-weight:300;line-height:1.78;color:var(--ink-2)}

.body-rule{max-width:860px;margin:64px auto 8px;padding:0 52px;display:flex;align-items:center;gap:22px}
.body-rule .br-k{font-size:10.5px;font-weight:500;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-3);white-space:nowrap}
.body-rule .br-l{height:1px;background:var(--line);flex:1}

/* numbered guide items */
.guide{max-width:860px;margin:0 auto;padding:0 52px}
.guide-item{padding:52px 0;border-bottom:1px solid var(--line)}
.guide-item:last-child{border-bottom:none}
.gi-head{display:flex;align-items:baseline;gap:16px;margin-bottom:18px}
.gi-num{font-family:'DM Serif Display',Georgia,serif;font-size:1.5rem;color:var(--red);line-height:1;min-width:42px}
.gi-h{font-family:'DM Serif Display',Georgia,serif;font-weight:400;font-size:1.7rem;line-height:1.16;letter-spacing:-.02em;color:var(--ink)}
.gi-p{font-size:1.06rem;font-weight:300;line-height:1.82;color:var(--ink-2)}
.gi-media{position:relative;margin-top:28px;aspect-ratio:16/9;overflow:hidden;border-radius:6px;background:linear-gradient(135deg,#cdbfae,#9a8268)}
.gi-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}

/* pull quote */
.pull{max-width:960px;margin:24px auto;padding:64px 52px;text-align:center}
.pull p{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;font-style:italic;
  font-size:clamp(1.7rem,3.4vw,2.5rem);line-height:1.28;letter-spacing:-.015em;color:var(--ink);
}
.pull .pull-mark{display:block;width:34px;height:2px;background:var(--red);margin:0 auto 30px}

/* close */
.art-close{max-width:860px;margin:0 auto;padding:40px 52px 96px;text-align:center}
.art-close p{font-size:1.1rem;font-weight:300;line-height:1.78;color:var(--ink-2)}

/* ===== MORE FROM EXPLORE ===== */
.more{background:var(--off);border-top:1px solid var(--line);padding:88px 52px}
.more-inner{max-width:1200px;margin:0 auto}
.more-rule{display:flex;align-items:center;gap:22px;margin-bottom:50px}
.more-rule .mr-k{font-size:10.5px;font-weight:500;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-3);white-space:nowrap}
.more-rule .mr-l{height:1px;background:var(--line-2);flex:1}
.more-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:44px 38px}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .art-head,.art-body,.guide,.body-rule,.pull,.art-close,.more{padding-left:28px;padding-right:28px}
  .art-head{padding-top:116px}
  .art-body{padding-top:60px}
  .more-grid{grid-template-columns:1fr;gap:40px}
}
</style>
