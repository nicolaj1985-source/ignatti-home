<template>
  <div>
    <!-- HEADER -->
    <section class="explore-head">
      <div class="explore-head-inner">
        <SectionLabel>Explore</SectionLabel>
        <h1>The places worth leaving the villa for.</h1>
        <p>Scouted in person by the people who manage the homes. We go first, on an ordinary weekday, and write up only what we would send our own guests to.</p>
      </div>
    </section>

    <!-- FEATURED -->
    <section class="featured-sec">
      <NuxtLink class="featured" :to="featured.path">
        <div class="featured-media">
          <img :src="featured.image" :alt="featured.alt" @error="(e) => (e.target.style.display = 'none')">
        </div>
        <div class="featured-text">
          <span class="featured-tag">{{ featured.tag }}</span>
          <h2 class="featured-title">{{ featured.title }}</h2>
          <p class="featured-stand">{{ featured.stand }}</p>
          <span class="featured-more">
            <span class="fm-line">Read the guide</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </span>
        </div>
      </NuxtLink>
    </section>

    <!-- GRID -->
    <section class="grid-sec">
      <div class="grid-rule">
        <span class="gr-k">The latest</span>
        <span class="gr-l"></span>
      </div>
      <div class="grid">
        <ArticleCard
          v-for="card in cards"
          :key="card.title"
          :to="articleLink"
          :image="card.image"
          :alt="card.alt"
          :tag="card.tag"
          :title="card.title"
          :stand="card.stand"
          :gradient="card.gradient"
        />
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed } from 'vue'

useSeoMeta({
  title: 'Explore — Ignatti Homes',
  description:
    'The places worth leaving the villa for. Scouted in person by the people who manage the homes — only what we would send our own guests to.',
  ogTitle: 'Explore — Ignatti Homes',
  ogDescription: 'The places worth leaving the villa for.',
  ogType: 'website',
})

// Pull published articles from Nuxt Content; newest first.
const { data: articles } = await useAsyncData('explore-index', () =>
  queryContent('explore').sort({ date: -1 }).find(),
)

// The featured slot shows the most recent real article (falls back to Nerja
// so the page always renders even before the content query resolves).
const featured = computed(() => {
  const a = articles.value && articles.value.length ? articles.value[0] : null
  if (!a) {
    return {
      path: '/explore/nerja-slowly',
      image: 'https://images.unsplash.com/photo-1558642084-fd07fae5282e?w=1600&q=80&auto=format&fit=crop',
      alt: 'The white town of Nerja above the Mediterranean',
      tag: 'Nerja · A Town Guide',
      title: 'Nerja, slowly',
      stand: 'Forty years a holiday town, and still worth it — if you arrive knowing when to ignore the crowds. Where we would send you, and what we would quietly walk past.',
    }
  }
  return {
    path: a._path,
    image: a.heroImage,
    alt: a.heroAlt || a.title,
    tag: [a.location, a.category].filter(Boolean).join(' · '),
    title: a.title,
    stand: a.featuredStand || a.standfirst,
  }
})

// Until more articles are published, the grid shows curated seed cards
// (mirroring the prototype). They link to the one live article. Swap this for
// `articles` once several markdown files exist in content/explore/.
const articleLink = computed(() => featured.value.path)

const cards = [
  { tag: 'Ronda · Where to Stay', title: 'The hotel we keep returning to', stand: 'A converted palace above the gorge. We have stayed four times. Here is why we ask for the same room.', image: 'https://images.unsplash.com/photo-1455587734955-081b22074882?w=1100&q=80&auto=format&fit=crop', alt: 'A converted palace hotel above the gorge in Ronda', gradient: 'linear-gradient(135deg,#cbb9a4,#8a6f52)' },
  { tag: 'Cómpeta · Dining', title: 'Dinner at the end of the road', stand: 'A mountain village, a single very good kitchen, and a drive home under the stars. Worth every kilometre.', image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1100&q=80&auto=format&fit=crop', alt: 'A small dining room at dusk', gradient: 'linear-gradient(135deg,#d8a47f,#b5754f)' },
  { tag: 'Maro · Experience', title: 'Where to swim when the beaches fill', stand: 'A cove below the cliffs, reached on foot down a path that discourages the casual. Go before ten, or not at all.', image: 'https://images.unsplash.com/photo-1505228395891-9a51e7e86bf6?w=1100&q=80&auto=format&fit=crop', alt: 'A quiet cove below the cliffs near Maro', gradient: 'linear-gradient(135deg,#7fc6d8,#3f8fb0)' },
  { tag: 'Marbella · A Long Lunch', title: 'Sunday, unhurried', stand: 'Not brunch as a performance. A long table, a good bottle, and nowhere to be for the rest of the afternoon.', image: 'https://images.unsplash.com/photo-1551218808-94e220e084d2?w=1100&q=80&auto=format&fit=crop', alt: 'A long lunch table set outdoors', gradient: 'linear-gradient(135deg,#e0c08a,#b89456)' },
  { tag: 'Ronda · Wine', title: 'A vineyard above the clouds', stand: 'Some of the highest vines in the region. We went for the view and stayed for what was in the glass.', image: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=1100&q=80&auto=format&fit=crop', alt: 'Vineyard rows above the coast', gradient: 'linear-gradient(135deg,#a9b18f,#6e7a52)' },
  { tag: 'Frigiliana · A Town Guide', title: 'The white town, before the buses', stand: 'Fifteen minutes from Nerja and a century away. Walk it early, while it still belongs to the people who live there.', image: 'https://images.unsplash.com/photo-1591792702338-78bc5a0c4c80?w=1100&q=80&auto=format&fit=crop', alt: 'A white street in Frigiliana, early morning', gradient: 'linear-gradient(135deg,#cdbfae,#9a8268)' },
  { tag: 'Marbella · Coffee', title: 'Morning coffee, done properly', stand: 'Where we go before the day starts. Small, exacting, and unbothered by the promenade outside.', image: 'https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?w=1100&q=80&auto=format&fit=crop', alt: 'A small coffee bar counter', gradient: 'linear-gradient(135deg,#b08a9e,#6e4f63)' },
  { tag: 'Estepona · Experience', title: 'The old town, repainted', stand: 'A working town that quietly became beautiful. We went to see whether it was real. It is.', image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1100&q=80&auto=format&fit=crop', alt: 'The repainted old town of Estepona', gradient: 'linear-gradient(135deg,#9ab0bd,#5b7a88)' },
  { tag: 'Marbella · Dining', title: 'A table worth the drive inland', stand: 'Twenty minutes from the coast, in a village most guests never reach. The reason to make the trip is the kitchen.', image: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=1100&q=80&auto=format&fit=crop', alt: 'A table at the edge of a cliff restaurant', gradient: 'linear-gradient(135deg,#d6b48f,#a87f4f)' },
]
</script>

<style scoped>
/* ===== HEADER ===== */
.explore-head{padding:158px 52px 18px;text-align:center}
.explore-head-inner{max-width:760px;margin:0 auto}
.explore-head h1{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;
  font-size:clamp(2.6rem,5.2vw,4rem);line-height:1.08;letter-spacing:-.026em;color:var(--ink);margin-bottom:26px;
}
.explore-head p{font-size:1.12rem;font-weight:300;line-height:1.7;color:var(--ink-2);max-width:580px;margin:0 auto}

/* ===== FEATURED ===== */
.featured-sec{padding:64px 52px 30px}
.featured{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1.32fr 1fr;gap:54px;align-items:center}
.featured-media{position:relative;aspect-ratio:16/11;overflow:hidden;border-radius:6px;background:linear-gradient(135deg,#cbb9a4,#9a8268)}
.featured-media img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .8s ease}
.featured:hover .featured-media img{transform:scale(1.035)}
.featured-tag{font-size:10.5px;font-weight:500;letter-spacing:.18em;text-transform:uppercase;color:var(--red);margin-bottom:18px;display:block}
.featured-title{
  font-family:'DM Serif Display',Georgia,serif;font-weight:400;
  font-size:clamp(2rem,3.4vw,2.9rem);line-height:1.12;letter-spacing:-.02em;color:var(--ink);margin-bottom:20px;transition:color .22s;
}
.featured:hover .featured-title{color:var(--red)}
.featured-stand{font-size:1.06rem;font-weight:300;line-height:1.74;color:var(--ink-2);margin-bottom:26px;max-width:440px}
.featured-more{display:inline-flex;align-items:center;gap:9px;font-size:12px;font-weight:500;letter-spacing:.08em;text-transform:uppercase;color:var(--ink)}
.featured-more svg{width:14px;height:14px;transition:transform .22s}
.featured:hover .featured-more svg{transform:translateX(4px)}
.featured-more .fm-line{color:var(--red)}

/* ===== GRID ===== */
.grid-sec{padding:56px 52px 30px}
.grid-rule{max-width:1200px;margin:0 auto 56px;display:flex;align-items:center;gap:22px}
.grid-rule .gr-k{font-size:10.5px;font-weight:500;letter-spacing:.2em;text-transform:uppercase;color:var(--ink-3);white-space:nowrap}
.grid-rule .gr-l{height:1px;background:var(--line);flex:1}
.grid{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:56px 40px}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .explore-head,.featured-sec,.grid-sec{padding-left:28px;padding-right:28px}
  .explore-head{padding-top:120px}
  .featured{grid-template-columns:1fr;gap:28px}
  .featured-media{aspect-ratio:16/10}
  .grid{grid-template-columns:repeat(2,1fr);gap:46px 30px}
}
@media(max-width:620px){
  .grid{grid-template-columns:1fr;gap:44px}
}
</style>
