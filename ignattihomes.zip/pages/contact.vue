<template>
  <div>
    <!-- HEADER -->
    <header class="contact-header">
      <SectionLabel>Begin a Conversation</SectionLabel>

      <!--
        Headline options — one active below, others available:
        A (active): "If your property fits, we should talk."
        B: "Every property we manage begins with a conversation."
        C: "We only work with villas we believe in."
      -->
      <h1 class="contact-title">If your property fits,<br>we should talk.</h1>

      <p class="contact-lead">
        We manage a small number of properties along the Costa del Sol.
        If you own a villa there and care about how it's run and presented,
        we'd like to hear from you.
      </p>
    </header>

    <!-- FORM -->
    <section class="contact-form-wrap" id="contact-form">
      <div class="cf-divider"></div>

      <form v-if="!submitted" novalidate @submit.prevent="onSubmit">
        <div class="cf-row cf-row--2">
          <div class="cf-field">
            <label class="cf-label" for="cf-name">Name</label>
            <input id="cf-name" v-model="form.name" type="text" name="name" required autocomplete="name">
          </div>
          <div class="cf-field">
            <label class="cf-label" for="cf-email">Email</label>
            <input id="cf-email" v-model="form.email" type="email" name="email" required autocomplete="email">
          </div>
        </div>

        <div class="cf-row cf-row--2">
          <div class="cf-field">
            <label class="cf-label" for="cf-phone">Phone <span class="opt">— optional</span></label>
            <input id="cf-phone" v-model="form.phone" type="tel" name="phone" autocomplete="tel">
          </div>
          <div class="cf-field">
            <label class="cf-label" for="cf-location">Property location</label>
            <input id="cf-location" v-model="form.location" type="text" name="location" required>
          </div>
        </div>

        <div class="cf-row cf-row--1">
          <div class="cf-field">
            <label class="cf-label" for="cf-message">Tell us about your property</label>
            <textarea id="cf-message" v-model="form.message" name="message" required></textarea>
          </div>
        </div>

        <div class="cf-row cf-row--1">
          <div class="cf-field">
            <label class="cf-label" for="cf-source">How did you hear about us?</label>
            <select id="cf-source" v-model="form.source" name="source">
              <option value="" disabled></option>
              <option value="word-of-mouth">Word of mouth</option>
              <option value="search">Online search</option>
              <option value="instagram">Instagram</option>
              <option value="press">Press or editorial</option>
              <option value="existing-owner">Referred by an existing owner</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>

        <div class="cf-submit">
          <button type="submit" class="btn-ig">
            Begin a conversation
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </button>
        </div>
      </form>

      <!-- inline success state -->
      <div v-else class="contact-success">
        <div class="success-rule"></div>
        <p class="success-heading">Thank you. We'll be in touch.</p>
        <p class="success-body">
          We read every message ourselves. If your property is a fit,
          you'll hear from us within two business days.
        </p>
      </div>
    </section>

    <!-- QUIET DETAILS -->
    <div class="contact-details">
      <div class="cd-item">
        <span class="cd-label">Email</span>
        <a href="mailto:hello@ignattihomes.com" class="cd-value">hello@ignattihomes.com</a>
      </div>
      <div class="cd-item">
        <span class="cd-label">Area served</span>
        <span class="cd-value">Costa del Sol corridor —<br>Marbella, Benahavís, La Zagaleta, the Golden Mile</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'

useSeoMeta({
  title: 'Contact — Ignatti Homes',
  description:
    'If your villa belongs in a collection this selective, the first step is a conversation. No sales process — a person reads every message and replies personally.',
  ogTitle: 'Contact — Ignatti Homes',
  ogDescription: 'If your property fits, we should talk.',
  ogType: 'website',
})

const form = reactive({
  name: '',
  email: '',
  phone: '',
  location: '',
  message: '',
  source: '',
})

const submitted = ref(false)

async function onSubmit() {
  // Routes through the shared composable; inline success state shows on resolve.
  await submitEnquiry({ ...form })
  submitted.value = true
}
</script>

<style scoped>
/* ===== HEADER ===== */
.contact-header{max-width:860px;margin:0 auto;padding:150px 52px 56px}
.contact-title{
  font-family:'DM Serif Display',Georgia,serif;
  font-size:clamp(2.4rem,5vw,3.6rem);font-weight:400;line-height:1.1;letter-spacing:-.028em;
  color:var(--ink);margin-bottom:28px;
}
.contact-lead{font-size:1.0625rem;font-weight:300;line-height:1.75;color:var(--ink-2);max-width:520px}

/* ===== FORM ===== */
.contact-form-wrap{max-width:860px;margin:0 auto;padding:0 52px 100px}
.cf-divider{width:34px;height:2px;background:var(--line-2);margin-bottom:52px}
.cf-row{display:grid;gap:28px;margin-bottom:28px}
.cf-row--2{grid-template-columns:1fr 1fr}
.cf-row--1{grid-template-columns:1fr}
.cf-field{display:flex;flex-direction:column;gap:8px}
.cf-label{font-family:'Inter',sans-serif;font-size:.75rem;font-weight:500;letter-spacing:.07em;text-transform:uppercase;color:var(--ink-2)}
.cf-label .opt{font-weight:300;letter-spacing:0;text-transform:none;font-size:.8125rem;color:var(--ink-3);margin-left:5px}
.cf-field input,.cf-field textarea,.cf-field select{
  width:100%;border:1px solid var(--line-2);border-radius:4px;background:#fff;
  font-family:'Inter',sans-serif;font-size:1rem;font-weight:300;color:var(--ink);
  padding:13px 16px;transition:border-color .22s,box-shadow .22s;-webkit-appearance:none;appearance:none;
}
.cf-field input:focus,.cf-field textarea:focus,.cf-field select:focus{
  outline:none;border-color:var(--red);box-shadow:0 0 0 3px rgba(200,16,46,.07);
}
.cf-field textarea{resize:vertical;min-height:148px;line-height:1.65}
.cf-field select{
  cursor:pointer;
  background-image:url("data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%239e9e9e' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
  background-repeat:no-repeat;background-position:right 14px center;background-size:16px;padding-right:44px;
}
.cf-field select:invalid{color:var(--ink-3)}
.cf-submit{margin-top:44px}

/* ===== SUCCESS ===== */
.contact-success{padding-bottom:16px}
.success-rule{width:34px;height:2px;background:var(--red);margin-bottom:40px}
.success-heading{font-family:'DM Serif Display',Georgia,serif;font-size:2rem;font-weight:400;line-height:1.25;color:var(--ink);margin-bottom:20px}
.success-body{font-size:1rem;font-weight:300;line-height:1.75;color:var(--ink-2);max-width:460px}

/* ===== QUIET DETAILS STRIP ===== */
.contact-details{border-top:1px solid var(--line);max-width:860px;margin:0 auto;padding:48px 52px 88px;display:flex;gap:72px;flex-wrap:wrap}
.cd-item{display:flex;flex-direction:column;gap:7px}
.cd-label{font-size:.7rem;font-weight:500;letter-spacing:.1em;text-transform:uppercase;color:var(--ink-3)}
.cd-value{font-size:.9375rem;font-weight:300;color:var(--ink-2);text-decoration:none;line-height:1.6}
a.cd-value:hover{color:var(--ink)}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .contact-header{padding-left:28px;padding-right:28px;padding-top:120px}
  .contact-form-wrap{padding-left:28px;padding-right:28px}
  .contact-details{padding-left:28px;padding-right:28px}
}
@media(max-width:680px){
  .cf-row--2{grid-template-columns:1fr}
  .contact-details{gap:40px}
}
</style>
