<template>
  <div>
    <!-- OPENING -->
    <section class="about-hero">
      <div class="about-hero-inner">
        <SectionLabel>About Ignatti Homes</SectionLabel>
        <h1 class="sec-title">Some villas are managed. <em>A select few are chosen.</em></h1>
        <p class="about-lead">Ignatti Homes manages a select portfolio of villas on the Costa del Sol corridor. If you own one of them, that selectivity is what protects it. If you are choosing where to stay, it is what you feel the moment you walk in — a standard the public platforms were never built to hold. What follows is not a brochure. It is how a property is chosen, and why that matters to both of you.</p>
      </div>
    </section>

    <!-- PHILOSOPHY -->
    <section class="about-philosophy">
      <div class="about-philosophy-inner">
        <SectionLabel>Our Philosophy</SectionLabel>
        <h2 class="sec-title">Full attention is a finite resource.</h2>
        <div class="sec-body">
          <p>Every property accepted here draws on the same finite reserve of attention, judgement, and care. That is why the list stays short. Your villa would not be added to a portfolio — it would be chosen for one, held to a standard that cannot be stretched across a hundred others. It is the same restraint a guest feels on arrival, in a home that is clearly looked after rather than merely listed.</p>
          <p>Decisions here are made on long-term asset value, not short-term yield. For you, that means the wrong booking is turned down and your nightly rate is protected, even when filling the gap would be the easier number to report. A villa run for this month's revenue is a villa quietly losing value. Yours is managed for the years you intend to own it.</p>
          <p>None of this is a posture adopted to stand out. It is the reason the company exists.</p>
        </div>
      </div>
    </section>

    <!-- LIFESTYLE BREAK -->
    <LifestyleBreak
      compact
      image="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=2200&q=85"
      alt="White Mediterranean architecture in full sun"
      place="Benahavís &nbsp;·&nbsp; La Zagaleta"
      line="A stretch of coast that asks more of the people who manage it."
    />

    <!-- WHY & GOAL -->
    <section class="about-why">
      <div class="about-why-inner">
        <SectionLabel>Our Why &amp; Our Goal</SectionLabel>
        <h2 class="sec-title">Not the largest name on the corridor. <em>The most trusted.</em></h2>
        <div class="sec-body">
          <p>The Costa del Sol does not lack villa management companies. What it lacks is one you can hand the keys to and genuinely stop thinking about. If you have searched for that and not found it, you already understand why this company exists.</p>
          <p>The ambition here is narrow, and deliberately so: to be the most trusted name in luxury villa management on this corridor — Marbella, Benahavís, La Zagaleta, the Golden Mile. Not the largest. The most trusted. Volume is not the measure; the standard your property is held to is. The two rarely describe the same company.</p>
          <p>Trust is not won in a pitch. It is earned slowly — across the months that go well and the ones that do not. This is built for the owner still here in a decade, not the one signed this quarter. If that is how you intend to own, you are exactly who it was made for.</p>
        </div>
      </div>
    </section>

    <!-- LIFESTYLE BREAK -->
    <LifestyleBreak
      compact
      image="https://images.unsplash.com/photo-1540541338287-41700207dee6?w=2200&q=85"
      alt="The Costa del Sol coastline in full daylight"
      img-style="filter:saturate(1.18) brightness(1.13) contrast(.98)"
      place="The Costa del Sol"
      line="Built for the owner who is still here in ten years."
    />

    <!-- WHY CHOOSE US -->
    <section class="about-choose">
      <div class="about-choose-inner">
        <SectionLabel>Why Owners Choose Us</SectionLabel>
        <h2 class="sec-title">The difference is what you stop carrying.</h2>
        <div class="sec-body">
          <p>Owners rarely leave a manager over a single failure. They leave because the small worries never stopped — the call at eleven at night, the booking that felt wrong, the report that never quite arrived. This is what changes the day you join.</p>
        </div>

        <div class="about-list">
          <div v-for="item in reasons" :key="item.h" class="ac-item">
            <div class="ac-h">{{ item.h }}</div>
            <div class="ac-p">{{ item.p }}</div>
          </div>
        </div>
      </div>
    </section>

    <!-- CLOSE -->
    <section class="about-close">
      <div class="about-close-inner">
        <SectionLabel>Begin a Conversation</SectionLabel>
        <h2 class="sec-title">If your villa belongs in a collection <em>this selective.</em></h2>
        <p class="about-close-sub">A handful of properties are accepted each year. Not every enquiry becomes one. If you believe yours belongs here, the first step is not a sales process — it is a conversation, and it begins whenever you are ready.</p>
        <NuxtLink class="contact-link" to="/contact">
          Begin a conversation
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
        </NuxtLink>
      </div>
    </section>
  </div>
</template>

<script setup>
useSeoMeta({
  title: 'About — Ignatti Homes',
  description:
    'Some villas are managed. A select few are chosen. How a property earns its place in a deliberately small portfolio on the Costa del Sol — and why that protects both owners and guests.',
  ogTitle: 'About — Ignatti Homes',
  ogDescription:
    'Full attention is a finite resource. Why the list stays short, and what that means for the homes on it.',
  ogType: 'website',
})

const reasons = [
  { h: 'Your rate is protected.', p: 'We price for the value of the asset, not the pressure of an empty calendar. The bookings we decline matter as much as the ones we accept.' },
  { h: 'You stop vetting strangers.', p: 'Every guest is reviewed by a person before they come near your home. They are chosen as carefully as the homes are. The standard does not move, and it does not bend for a strong week\'s revenue.' },
  { h: 'Problems reach us before they reach you.', p: 'Your property is inspected before and after every stay. Most issues are resolved before you would ever have known there was one.' },
  { h: 'You always know where you stand.', p: 'Clear numbers arrive every month, without being asked — revenue, occupancy, costs, and the honest reading behind them. The difficult months included.' },
]
</script>

<style scoped>
/* ===== OPENING ===== */
.about-hero{padding:176px 52px 100px}
.about-hero-inner{max-width:900px;margin:0 auto}
.about-hero .sec-title{font-size:clamp(2.8rem,5.6vw,4.3rem);line-height:1.06;margin-bottom:34px;max-width:880px}
.about-lead{font-size:1.2rem;font-weight:300;line-height:1.74;color:var(--ink-2);max-width:660px}

/* ===== PHILOSOPHY (centered rhythm) ===== */
.about-philosophy{padding:112px 52px;text-align:center}
.about-philosophy-inner{max-width:800px;margin:0 auto}
.about-philosophy .sec-body{max-width:640px;margin:0 auto;text-align:left}

/* ===== WHY & GOAL (left rhythm) ===== */
.about-why{padding:112px 52px}
.about-why-inner{max-width:900px;margin:0 auto}
.about-why .sec-title{max-width:780px}
.about-why .sec-body{max-width:660px}

/* ===== WHY CHOOSE US (left rhythm + consequence list) ===== */
.about-choose{padding:112px 52px}
.about-choose-inner{max-width:900px;margin:0 auto}
.about-choose .sec-body{max-width:660px}
.about-list{margin-top:60px;border-top:1px solid var(--line-2)}
.ac-item{padding:44px 0;border-bottom:1px solid var(--line)}
.ac-item:last-child{border-bottom:none}
.ac-h{font-family:'DM Serif Display',Georgia,serif;font-size:1.6rem;letter-spacing:-.02em;line-height:1.18;color:var(--ink);margin-bottom:14px}
.ac-p{font-size:1.02rem;font-weight:300;line-height:1.82;color:var(--ink-2);max-width:620px}

/* ===== CLOSE (centered, single CTA) ===== */
.about-close{padding:124px 52px 144px;border-top:1px solid var(--line);text-align:center}
.about-close-inner{max-width:700px;margin:0 auto}
.about-close .sec-title{margin-bottom:24px}
.about-close-sub{font-size:1.02rem;font-weight:300;line-height:1.78;color:var(--ink-2);max-width:520px;margin:0 auto 40px}

/* ===== RESPONSIVE ===== */
@media(max-width:960px){
  .about-hero,.about-philosophy,.about-why,.about-choose,.about-close{padding-left:28px;padding-right:28px}
  .about-hero{padding-top:124px;padding-bottom:72px}
  .about-philosophy,.about-why,.about-choose{padding-top:80px;padding-bottom:80px}
  .about-close{padding-top:96px;padding-bottom:104px}
  .ac-item{padding:34px 0}
}
</style>
