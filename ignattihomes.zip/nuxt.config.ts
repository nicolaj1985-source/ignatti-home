// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  compatibilityDate: '2025-01-01',
  devtools: { enabled: false },

  // Nuxt Content powers the Explore articles (content/explore/*.md).
  // @nuxtjs/sitemap generates /sitemap.xml. Per-page meta + Open Graph
  // are set with the built-in useSeoMeta() in each page.
  modules: ['@nuxt/content', '@nuxtjs/sitemap'],

  css: ['~/assets/css/main.css'],

  // Used by @nuxtjs/sitemap and as the canonical site identity for SEO.
  // Change this to the production domain before launch.
  site: {
    url: 'https://ignattihomes.com',
    name: 'Ignatti Homes',
  },

  // Pre-render the whole site as static HTML. crawlLinks follows the
  // in-page links (including the Explore article) so every route — and the
  // sitemap — is generated at build time. Deploys to Vercel with zero config.
  nitro: {
    prerender: {
      crawlLinks: true,
      // '/' seeds the crawl (every page is reachable from the nav / featured
      // links); '/sitemap.xml' isn't linked from any page, so list it directly.
      routes: ['/', '/sitemap.xml'],
    },
  },

  app: {
    head: {
      htmlAttrs: { lang: 'en' },
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      ],
      link: [
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
        { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: '' },
        {
          rel: 'stylesheet',
          href: 'https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:wght@300;400;500;600&display=swap',
        },
      ],
    },
  },
})
