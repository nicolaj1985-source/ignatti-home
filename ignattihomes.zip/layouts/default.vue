<template>
  <div class="site">
    <SiteNav />
    <main>
      <slot />
    </main>
    <SiteFooter />
  </div>
</template>

<script setup>
// Wraps every page with the canonical fixed navbar + off-white footer.
// Components are auto-imported by Nuxt from ~/components.
</script>
